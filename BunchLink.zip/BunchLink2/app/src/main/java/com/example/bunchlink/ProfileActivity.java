package com.example.bunchlink;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;

import de.hdodenhof.circleimageview.CircleImageView;


public class ProfileActivity extends AppCompatActivity {
    Button btn_complete;
    TextView username, contakt, phone, firstname, lastname, birthdate;
    ImageButton facebook, linkin, instagram, back;
    CircleImageView image_profile;
    DatabaseReference reference;
    FirebaseUser fuser;
    StorageReference storageReference;
    private static final int IMAGE_REQUEST = 1;
    private Uri imageUri;
    private StorageTask<UploadTask.TaskSnapshot> uploadTask;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        image_profile = findViewById(R.id.image_profile);
        username = findViewById(R.id.username);
        contakt = findViewById(R.id.contakt);
        phone = findViewById(R.id.phone);
        firstname = findViewById(R.id.firstname);
        lastname = findViewById(R.id.lastname);
        birthdate = findViewById(R.id.birthdate);
        facebook = findViewById(R.id.facebook);
        linkin = findViewById(R.id.linkin);
        instagram = findViewById(R.id.instagram);
        back = findViewById(R.id.back);
        btn_complete = findViewById(R.id.btn_complete);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ProfileActivity.this, MainActivity.class));
            }
        });

        btn_complete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String txt_email = contakt.getText().toString();
                String txt_password = password.getText().toString();
                String txt_com_pass = password_confirm.getText().toString();
                if (TextUtils.isEmpty(txt_username) || TextUtils.isEmpty(txt_email) || TextUtils.isEmpty(txt_password) || TextUtils.isEmpty(txt_com_pass)) {
                    Toast.makeText(RegisterActivity.this, "Všechny pole musí být plná!!!", Toast.LENGTH_SHORT).show();
                } else if (txt_password.length() < 8) {
                    Toast.makeText(RegisterActivity.this, "Heslo je příliš krátké!!!", Toast.LENGTH_SHORT).show();
                } else if (!txt_password.equals(txt_com_pass)) {
                    Toast.makeText(RegisterActivity.this, "Hesla se musí shodovat!!!", Toast.LENGTH_SHORT).show();
                }else {
                    register(txt_username, txt_email, txt_password);

                }
                startActivity(new Intent(ProfileActivity.this, MainActivity.class));
            }
        });

    }
}
